#define NV_COMPILER "gcc version 11.3.0 (Gentoo 11.3.0 p4) "
