#define NV_COMPILER "gcc version 9.3.0 (Gentoo 9.3.0 p2) "
